import Counter from "./components/Counter.jsx";
import SetStateClass from "./components/SetStateClass.jsx";
import SetStateFunction from "./components/SetStateFunction.jsx";
import Parent from "./components/Parent.jsx";

function App() {
  return (
    <div className={'container mt-5'}>
      <h3>state 없이 버튼 클릭 시 count 값 변경해보기</h3>
      <Counter/>

      <hr/>

      <h3>클래스 컴포넌트에서 state 사용하기</h3>
      <SetStateClass/>
      <br/>

      <h3>함수 컴포넌트에서 state 사용하기</h3>
      <SetStateFunction/>
      <br/>

      <br/>
      <hr/>
      <br/>

      <h3>props와 state의 차이</h3>
      <Parent/>


      <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
    </div>
  );
}

export default App
